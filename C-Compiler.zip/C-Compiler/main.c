#include <stdio.h>

int main() {
  
  printf("WELCOME TO THE GRADE POINTS AVERAGE CALCULATOR!\n\n");
  float midterm, final, project, average;
  printf("Enter your midterm grade: ");
  scanf("%f", &midterm);
  printf("Enter your final grade: ");
  scanf("%f", &final);
  printf("Enter your project grade: ");
  scanf("%f", &project);
  average = (midterm*30/100 + final*50/100 + project*20/100);
   printf("\nYour average grade: %f\n", average);
  if (average >= 70) {
    printf("Congratulations! You have passed the course.\n");
    } 
  else {
    printf("Sorry, you have failed the course.\n");
    }

    return 0;
}